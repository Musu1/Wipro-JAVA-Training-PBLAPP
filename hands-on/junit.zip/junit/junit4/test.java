package test2;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({
		calculatorTest.class,
		StringmanipTest.class
	})

public class test {
		
		public class AllTests {
			
		}
	}
