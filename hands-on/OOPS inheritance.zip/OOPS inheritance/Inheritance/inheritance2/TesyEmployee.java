package inheritance2;

public class TesyEmployee {

	public static void main(String[] args) {
		Person p=new Person();
		Employee e=new Employee();
		p.get();
		e.get();
		p.set();
		e.set();
	}

}
