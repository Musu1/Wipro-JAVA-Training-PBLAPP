public class IfStatement2{
	public static void main(String args[]){
		int a=Integer.parseInt(args[0]);
		if(a%2==0){
		   System.out.print("The number is even");
		}
		else{
		   System.out.print("The number is odd");
		}
}}