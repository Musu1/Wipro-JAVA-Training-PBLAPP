create table dept(DEPT_ID NUMBER(7) CONSTRAINT department_id_pk PRIMARY KEY,DEPT_NAME VARCHAR2(20));
DESC dept;