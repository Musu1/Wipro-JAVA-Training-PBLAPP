insert into dept(dept_id,dept_name) values(10,'Accounts');
insert into dept(dept_id,dept_name) values(20,'TT');
insert into dept(dept_id,dept_name) values(30,'Accounts');
select * from dept;