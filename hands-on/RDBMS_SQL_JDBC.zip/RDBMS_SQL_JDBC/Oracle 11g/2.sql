select * from tab;
desc EMPLOYEES;
SELECT * FROM EMPLOYEES;