package music.wind;

import music.Playable;

public class saxophone implements Playable {
	public void play() {
		System.out.println("Plays saxophone");
	}
}
