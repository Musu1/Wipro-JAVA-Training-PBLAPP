package com.wipro.automobile.ship;

public class assignment2 {

	public static void main(String[] args) {
		compartment c=new compartment(4.5,5.5,8.4);
		System.out.println(c.display());

	}

}
