package assignment;

import testPackage.Foundation;
public class assignment1 {

	public static void main(String[] args) {
		Foundation foundation=new Foundation();
		System.out.println(foundation.var4);

	}

}
